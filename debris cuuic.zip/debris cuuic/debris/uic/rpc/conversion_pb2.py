

from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from google.protobuf import reflection as _reflection
from google.protobuf import symbol_database as _symbol_database
# @@protoc_insertion_point(imports)

_sym_db = _symbol_database.Default()


from google.protobuf import wrappers_pb2 as google_dot_protobuf_dot_wrappers__pb2
import orbdetpy.rpc.messages_pb2 as messages__pb2


DESCRIPTOR = _descriptor.FileDescriptor(
  name='conversion.proto',
  package='',
  syntax='proto3',
  serialized_options=b'\n\016org.astria.rpcB\021ConversionRequestP\000',
  create_key=_descriptor._internal_create_key,
  serialized_pb=b'\n\x10\x63onversion.proto\x1a\x1egoogle/protobuf/wrappers.proto\x1a\x0emessages.proto2\xa7\x04\n\nConversion\x12\x38\n\x0etransformFrame\x12\x14.TransformFrameInput\x1a\x0e.Double2DArray\"\x00\x12\x32\n\x12\x63onvertAzElToRaDec\x12\x0c.AnglesInput\x1a\x0c.DoubleArray\"\x00\x12\x32\n\x12\x63onvertRaDecToAzEl\x12\x0c.AnglesInput\x1a\x0c.DoubleArray\"\x00\x12\x39\n\x0f\x63onvertPosToLLA\x12\x14.TransformFrameInput\x1a\x0e.Double2DArray\"\x00\x12\x39\n\x0f\x63onvertElemToPv\x12\x14.TransformFrameInput\x1a\x0e.Double2DArray\"\x00\x12\x39\n\x0f\x63onvertPvToElem\x12\x14.TransformFrameInput\x1a\x0e.Double2DArray\"\x00\x12<\n\x0cgetUTCString\x12\x0c.DoubleArray\x1a\x1c.google.protobuf.StringValue\"\x00\x12\x43\n\x13getJ2000EpochOffset\x12\x1c.google.protobuf.StringValue\x1a\x0c.DoubleArray\"\x00\x12\x43\n\x12getEpochDifference\x12\r.IntegerArray\x1a\x1c.google.protobuf.DoubleValue\"\x00\x42%\n\x0eorg.astria.rpcB\x11\x43onversionRequestP\x00\x62\x06proto3'
  ,
  dependencies=[google_dot_protobuf_dot_wrappers__pb2.DESCRIPTOR,messages__pb2.DESCRIPTOR,])



_sym_db.RegisterFileDescriptor(DESCRIPTOR)


DESCRIPTOR._options = None

_CONVERSION = _descriptor.ServiceDescriptor(
  name='Conversion',
  full_name='Conversion',
  file=DESCRIPTOR,
  index=0,
  serialized_options=None,
  create_key=_descriptor._internal_create_key,
  serialized_start=69,
  serialized_end=620,
  methods=[
  _descriptor.MethodDescriptor(
    name='transformFrame',
    full_name='Conversion.transformFrame',
    index=0,
    containing_service=None,
    input_type=messages__pb2._TRANSFORMFRAMEINPUT,
    output_type=messages__pb2._DOUBLE2DARRAY,
    serialized_options=None,
    create_key=_descriptor._internal_create_key,
  ),
  _descriptor.MethodDescriptor(
    name='convertAzElToRaDec',
    full_name='Conversion.convertAzElToRaDec',
    index=1,
    containing_service=None,
    input_type=messages__pb2._ANGLESINPUT,
    output_type=messages__pb2._DOUBLEARRAY,
    serialized_options=None,
    create_key=_descriptor._internal_create_key,
  ),
  _descriptor.MethodDescriptor(
    name='convertRaDecToAzEl',
    full_name='Conversion.convertRaDecToAzEl',
    index=2,
    containing_service=None,
    input_type=messages__pb2._ANGLESINPUT,
    output_type=messages__pb2._DOUBLEARRAY,
    serialized_options=None,
    create_key=_descriptor._internal_create_key,
  ),
  _descriptor.MethodDescriptor(
    name='convertPosToLLA',
    full_name='Conversion.convertPosToLLA',
    index=3,
    containing_service=None,
    input_type=messages__pb2._TRANSFORMFRAMEINPUT,
    output_type=messages__pb2._DOUBLE2DARRAY,
    serialized_options=None,
    create_key=_descriptor._internal_create_key,
  ),
  _descriptor.MethodDescriptor(
    name='convertElemToPv',
    full_name='Conversion.convertElemToPv',
    index=4,
    containing_service=None,
    input_type=messages__pb2._TRANSFORMFRAMEINPUT,
    output_type=messages__pb2._DOUBLE2DARRAY,
    serialized_options=None,
    create_key=_descriptor._internal_create_key,
  ),
  _descriptor.MethodDescriptor(
    name='convertPvToElem',
    full_name='Conversion.convertPvToElem',
    index=5,
    containing_service=None,
    input_type=messages__pb2._TRANSFORMFRAMEINPUT,
    output_type=messages__pb2._DOUBLE2DARRAY,
    serialized_options=None,
    create_key=_descriptor._internal_create_key,
  ),
  _descriptor.MethodDescriptor(
    name='getUTCString',
    full_name='Conversion.getUTCString',
    index=6,
    containing_service=None,
    input_type=messages__pb2._DOUBLEARRAY,
    output_type=google_dot_protobuf_dot_wrappers__pb2._STRINGVALUE,
    serialized_options=None,
    create_key=_descriptor._internal_create_key,
  ),
  _descriptor.MethodDescriptor(
    name='getJ2000EpochOffset',
    full_name='Conversion.getJ2000EpochOffset',
    index=7,
    containing_service=None,
    input_type=google_dot_protobuf_dot_wrappers__pb2._STRINGVALUE,
    output_type=messages__pb2._DOUBLEARRAY,
    serialized_options=None,
    create_key=_descriptor._internal_create_key,
  ),
  _descriptor.MethodDescriptor(
    name='getEpochDifference',
    full_name='Conversion.getEpochDifference',
    index=8,
    containing_service=None,
    input_type=messages__pb2._INTEGERARRAY,
    output_type=google_dot_protobuf_dot_wrappers__pb2._DOUBLEVALUE,
    serialized_options=None,
    create_key=_descriptor._internal_create_key,
  ),
])
_sym_db.RegisterServiceDescriptor(_CONVERSION)

DESCRIPTOR.services_by_name['Conversion'] = _CONVERSION

# @@protoc_insertion_point(module_scope)
